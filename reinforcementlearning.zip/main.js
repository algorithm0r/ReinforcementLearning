function randomInt(n) {
    return Math.floor(Math.random() * n);
}

function Agent(game, maze) {
    this.game = game;
    this.maze = maze;
    this.alpha = 0.5;
    this.reward = 0;
    this.originX = maze.type === 0 ? 3 : maze.type === 1 ? 0 : randomInt(this.maze.dim - 1);
    this.originY = maze.type === 0 ? 2 : 0;
    this.x = this.originX;
    this.y = this.originY;
    this.lastX = this.x;
    this.lastY = this.y;
    this.actionTimer = 0;
    this.actionThreshold = document.getElementById("speed").value;
    this.epsilon = 1;
    this.qLearner = document.getElementById("q").checked;
    this.explorer = document.getElementById("explorer").checked;
    this.drunk = document.getElementById("drunk").checked;
    this.updateAll = document.getElementById("update_explored").checked;
    this.steps = 0;
    this.decayThreshold = document.getElementById("epsilon_decay").value;
    this.decay = document.getElementById("epsilon").value;
};

Agent.prototype.update = function() {
    var cell = this.maze.maze[this.x][this.y];
    cell.explored = true;
    
    this.actionTimer += this.game.clockTick;
    if (this.actionTimer > this.actionThreshold) {
        this.steps++;
        if (this.steps % this.decayThreshold === 0) {
            this.epsilon *= this.decay;
        }
        this.actionTimer = 0;

        if (this.updateAll) this.maze.updateExploredValues();
        else this.maze.updateValue(this.x, this.y);

        if (cell.final) {
            this.x = this.maze.type === 2 ? randomInt(this.maze.dim) : this.originX;
            this.y = this.originY;
        } else {
            var moves = [];
            var unexplored = [];
            var bestmove = [];
            var bestvalue = -Infinity;

            var bestQmove = ["north"];
            var bestQ = cell.moveNorth.q;
            if (cell.moveEast.q > bestQ) {
                bestQ = cell.moveEast.q;
                bestQmove = [];
                bestQmove.push("east");
            }
            else if (cell.moveEast.q === bestQ) bestQmove.push("east");
            if (cell.moveSouth.q > bestQ) {
                bestQ = cell.moveSouth.q;
                bestQmove = [];
                bestQmove.push("south");
            }
            else if (cell.moveSouth.q === bestQ) bestQmove.push("south");
            if (cell.moveWest.q > bestQ) {
                bestQ = cell.moveWest.q;
                bestQmove = [];
                bestQmove.push("west");
            }
            else if (cell.moveWest.q === bestQ) bestQmove.push("west");

            if (cell.north) {
                if (cell.north.value > bestvalue) {
                    bestvalue = cell.north.value;
                    bestmove = [];
                    bestmove.push("north");
                }
                else if (cell.north.value === bestvalue) bestmove.push("north");
                if(this.lastY !== this.y - 1 || !this.drunk) moves.push("north");
                if (!cell.north.explored) unexplored.push("north");
            }
            if (cell.east) {
                if (cell.east.value > bestvalue) {
                    bestvalue = cell.east.value;
                    bestmove = [];
                    bestmove.push("east");
                }
                else if (cell.east.value === bestvalue) bestmove.push("east");
                if (this.lastX !== this.x + 1 || !this.drunk) moves.push("east");
                if (!cell.east.explored) unexplored.push("east");
            }
            if (cell.south) {
                if (cell.south.value > bestvalue) {
                    bestvalue = cell.south.value;
                    bestmove = [];
                    bestmove.push("south");
                }
                else if (cell.south.value === bestvalue) bestmove.push("south");
                if (!cell.south.explored) unexplored.push("south");
                if (this.lastY !== this.y + 1 || !this.drunk) moves.push("south");
            }
            if (cell.west) {
                if (cell.west.value > bestvalue) {
                    bestvalue = cell.west.value;
                    bestmove = [];
                    bestmove.push("west");
                }
                else if (cell.west.value === bestvalue) bestmove.push("west");
                if (!cell.west.explored) unexplored.push("west");
                if (this.lastX !== this.x - 1 || !this.drunk) moves.push("west");
            }


            var move;
            if (this.explorer && unexplored.length > 0) {
                move = unexplored[randomInt(unexplored.length)];
            } else if (Math.random() < this.epsilon) {
                move = moves[randomInt(moves.length)];
            } else {
                if (this.qLearner) move = bestQmove[randomInt(bestQmove.length)];
                else move = bestmove[randomInt(bestmove.length)];
            }

            this.lastX = this.x;
            this.lastY = this.y;

            if (!move) {
                console.log(move);
                if (cell.north) move = "north";
                if (cell.south) move = "south";
                if (cell.east) move = "east";
                if (cell.west) move = "west";
            }

            this.move(move);
        }
    }
};

Agent.prototype.move = function (move) {
    var cell = this.maze.maze[this.x][this.y];
    var dist = null;
    if (move === "north") dist = cell.moveNorth;
    if (move === "east") dist = cell.moveEast;
    if (move === "south") dist = cell.moveSouth;
    if (move === "west") dist = cell.moveWest;
    dist.n++;
    var rand = Math.random();
    var i = 0;
    var sum = 0;
    while (rand > sum + dist.prob[i]) sum += dist.prob[i++];
    var newCell = dist.next[i];
    this.updateQ(cell, dist, newCell);
    this.reward += newCell.utility;
    this.x = newCell.x;
    this.y = newCell.y;
};

Agent.prototype.updateQ = function (cell, action, newCell) {
    var max = newCell.moveNorth.q;
    if (newCell.moveEast.q > max) max = newCell.moveEast.q;
    if (newCell.moveSouth.q > max) max = newCell.moveSouth.q;
    if (newCell.moveWest.q > max) max = newCell.moveWest.q;
    action.q += 1/(Math.ceil(action.n/100)) * (cell.utility + this.maze.gamma * (max - action.q));
};

Agent.prototype.draw = function (ctx) {
    var length = 800 / this.maze.dim;

    var tick = document.getElementById("tick");
    tick.innerHTML = "Tick: " + this.steps;

    var epsilon = document.getElementById("ep");
    epsilon.innerHTML = "Epsilon: " + Math.floor(this.epsilon * 100) / 100;

    var epsilon = document.getElementById("rew");
    epsilon.innerHTML = "Reward: " + Math.floor(this.reward * 100) / 100;

    ctx.drawImage(ASSET_MANAGER.getAsset("robo1.png"), this.x * length + 0.22 * length, this.y * length + 0.125 * length, length * 0.54, length * 0.75);
};

function Maze(game, type) {
    // type: 0 = 4x3, 1 = maze, 2 = bridge
    this.type = type;
    this.game = game;
    this.maze = [];
    this.icy = document.getElementById('icy') ? document.getElementById('icy').checked : false;
    this.slippy = document.getElementById('slippy') ? parseFloat(document.getElementById('slippy').value) : 0.1;
    this.gamma = document.getElementById('gamma') ? parseFloat(document.getElementById('gamma').value) : 0.9;

    if (type === 0) {
        this.dim = 4;
        this.reward = 1;

        this.makeGrid();
        this.generateFourByThree();
        this.attachMoves();
    } else if (type === 1) {
        this.dim = document.getElementById('dim') ? parseInt(document.getElementById('dim').value) : 10;
        this.reward = document.getElementById('reward') ? parseInt(document.getElementById('reward').value) : 10000;
        this.deleted = document.getElementById('walls_deleted') ? parseInt(document.getElementById('walls_deleted').value) : 0;
        this.pits = document.getElementById('pits') ? parseInt(document.getElementById('pits').value) : 0;

        this.makeGrid();
        this.generateMaze(0, 0);
        this.placePits(this.pits);
        this.breakWalls(this.deleted);
        this.maze[this.dim - 1][this.dim - 1].utility = this.reward;
        this.maze[this.dim - 1][this.dim - 1].final = true;
        this.attachMoves();
    } else if (type === 2) {
        this.dim = 10;
        this.reward = document.getElementById('reward') ? parseInt(document.getElementById('reward').value) : 10000;

        this.makeGrid();
        this.generateBridge();
        this.attachMoves();
    }
};

Maze.prototype.attachMoves = function () {

    if (!this.icy) {
        for (var i = 0; i < this.dim; i++) {
            for (var j = 0; j < this.dim; j++) {
                var cell = this.maze[i][j];
                cell.moveNorth = { next: [cell.north ? cell.north : cell], prob: [1], q: cell.utility, n:0 };
                cell.moveEast = { next: [cell.east ? cell.east : cell], prob: [1], q: cell.utility, n: 0 };
                cell.moveSouth = { next: [cell.south ? cell.south : cell], prob: [1], q: cell.utility, n: 0 };
                cell.moveWest = { next: [cell.west ? cell.west : cell], prob: [1], q: cell.utility, n: 0 };
            }
        }
    }
    else {
        for (var i = 0; i < this.dim; i++) {
            for (var j = 0; j < this.dim; j++) {
                var cell = this.maze[i][j];
                cell.moveNorth = { next: [cell.north ? cell.north : cell, cell.east ? cell.east : cell, cell.west ? cell.west : cell], prob: [1 - 2*this.slippy, this.slippy, this.slippy], q: cell.utility, n: 0 };
                cell.moveSouth = { next: [cell.south ? cell.south : cell, cell.east ? cell.east : cell, cell.west ? cell.west : cell], prob: [1 - 2 * this.slippy, this.slippy, this.slippy], q: cell.utility, n: 0 };
                cell.moveEast = { next: [cell.east ? cell.east : cell, cell.north ? cell.north : cell, cell.south ? cell.south : cell], prob: [1 - 2 * this.slippy, this.slippy, this.slippy], q: cell.utility, n: 0 };
                cell.moveWest = { next: [cell.west ? cell.west : cell, cell.north ? cell.north : cell, cell.south ? cell.south : cell], prob: [1 - 2 * this.slippy, this.slippy, this.slippy], q: cell.utility, n: 0 };
            }
        }
    }
};

Maze.prototype.generateBridge = function () {
    for (var i = 0; i < this.dim; i++) {
        for (var j = 0; j < this.dim; j++) {
            cell = this.maze[i][j];
            // no walls
            if (j !== 0) { // north
                cell.north = this.maze[i][j - 1];
            }
            if (i !== this.dim - 1) {
                cell.east = this.maze[i + 1][j];
            }
            if (j !== this.dim - 1) {
                cell.south = this.maze[i][j + 1];
            }
            if (i !== 0) {
                cell.west = this.maze[i - 1][j];
            }

            // add pits
            if (j > 1 && j < this.dim - 2 && (i < 3 || i > this.dim - 4)) {
                cell.utility = -this.reward;
                cell.final = true;
                cell.pit = true;
            }
        }
    }

    for (var i = 0; i < this.dim; i++) {
        this.maze[i][this.dim - 1].utility = this.reward;
        this.maze[i][this.dim - 1].final = true;
    }
};

Maze.prototype.generateFourByThree = function () {
    this.maze[0][0].east = this.maze[1][0];
    this.maze[0][0].south = this.maze[0][1];
    this.maze[1][0].east = this.maze[2][0];
    this.maze[1][0].west = this.maze[0][0];
    this.maze[2][0].east = this.maze[3][0];
    this.maze[2][0].west = this.maze[1][0];
    this.maze[2][0].south = this.maze[2][1];
    this.maze[3][0].west = this.maze[2][0];
    this.maze[0][1].north = this.maze[0][0];
    this.maze[0][1].south = this.maze[0][2];
    this.maze[2][1].south = this.maze[2][2];
    this.maze[2][1].north = this.maze[2][0];
    this.maze[2][1].east = this.maze[3][1];
    this.maze[3][1].west = this.maze[2][1];
    this.maze[3][1].south = this.maze[3][2];
    this.maze[0][2].north = this.maze[0][1];
    this.maze[0][2].east = this.maze[1][2];
    this.maze[1][2].east = this.maze[2][2];
    this.maze[1][2].west = this.maze[0][2];
    this.maze[2][2].east = this.maze[3][2];
    this.maze[2][2].west = this.maze[1][2];
    this.maze[2][2].north = this.maze[2][1];
    this.maze[3][2].west = this.maze[2][2];
    this.maze[3][2].north = this.maze[3][1];

    this.maze[3][0].utility = this.reward;
    this.maze[3][1].utility = -this.reward;
    this.maze[3][1].pit = true;
    this.maze[3][0].final = true;
    this.maze[3][1].final = true;
};

Maze.prototype.makeGrid = function () {
    for (var i = 0; i < this.dim; i++) {
        this.maze.push([]);
        for (var j = 0; j < this.dim; j++) {
            this.maze[i].push({
                x: i,
                y: j,
                north: null,
                east: null,
                south: null,
                west: null,
                moveNorth: null,
                moveEast: null,
                moveSouth: null,
                moveWest: null,
                visited: null,
                utility: -0.05,
                value: 0,
                solution: false,
                final: false,
                explored: false,
                pit: false
            });
        }
    }
};

Maze.prototype.placePits = function(num) {
    for (var i = 0; i < num; i++) {
        var x = randomInt(this.dim);
        var y = randomInt(this.dim);

        while (this.maze[x][y].pit) {
            x = randomInt(this.dim);
            y = randomInt(this.dim);
        }

        this.maze[x][y].pit = true;
        this.maze[x][y].utility = -this.reward;
        this.maze[x][y].final = true;
    }
};

Maze.prototype.breakWalls = function (num) {
    for (var k = 0; k < num; k++) {
        var walls = [];
        var cell;
        for (var i = 0; i < this.dim; i++) {
            for (var j = 0; j < this.dim; j++) {
                cell = this.maze[i][j];
                if (!cell.north && j !== 0) walls.push({ x: i, y: j, wall: "north" });
                if (!cell.east && i !== this.dim - 1) walls.push({ x: i, y: j, wall: "east" });
                if (!cell.south && j !== this.dim - 1) walls.push({ x: i, y: j, wall: "south" });
                if (!cell.west && i !== 0) walls.push({ x: i, y: j, wall: "west" });
            }
        }

        if (walls.length === 0) return; // no more walls to break

        var wall = walls[randomInt(walls.length)];
        cell = this.maze[wall.x][wall.y];

        if (wall.wall === "north") {
            cell.north = this.maze[wall.x][wall.y - 1];
            this.maze[wall.x][wall.y - 1].south = cell;
        }
        if (wall.wall === "east") {
            cell.east = this.maze[wall.x + 1][wall.y];
            this.maze[wall.x + 1][wall.y].west = cell;
        }
        if (wall.wall === "south") {
            cell.south = this.maze[wall.x][wall.y + 1];
            this.maze[wall.x][wall.y + 1].north = cell;
        }
        if (wall.wall === "west") {
            cell.west = this.maze[wall.x - 1][wall.y];
            this.maze[wall.x - 1][wall.y].east = cell;
        }
    }
};

Maze.prototype.updateValue = function (x, y) {
    var max = -Infinity;
    var cell = this.maze[x][y];
    var oldValue = cell.value;

    if (cell.final) {
        cell.value = cell.utility;
        return false;
    }
    
    var newValue = cell.utility;

    var dist = cell.moveNorth;
    var sum = 0;
    for (var i = 0; i < dist.next.length; i++) {
        sum += dist.next[i].value * dist.prob[i];
    }
    if (sum > max) max = sum;

    dist = cell.moveEast;
    sum = 0;
    for (var i = 0; i < dist.next.length; i++) {
        sum += dist.next[i].value * dist.prob[i];
    }
    if (sum > max) max = sum;

    dist = cell.moveSouth;
    sum = 0;
    for (var i = 0; i < dist.next.length; i++) {
        sum += dist.next[i].value * dist.prob[i];
    }
    if (sum > max) max = sum;

    dist = cell.moveWest;
    sum = 0;
    for (var i = 0; i < dist.next.length; i++) {
        sum += dist.next[i].value * dist.prob[i];
    }
    if (sum > max) max = sum;

    newValue += max * this.gamma;

    cell.value = newValue
    return (cell.value !== oldValue);
};

Maze.prototype.updateValues = function () {
    var changed = false;
    for (var i = 0; i < this.dim; i++) {
        for (var j = 0; j < this.dim; j++) {
            if (this.updateValue(i, j)) changed = true;
        }
    }
    return changed;
};

Maze.prototype.updateExploredValues = function () {
    var changed = false;
    for (var i = 0; i < this.dim; i++) {
        for (var j = 0; j < this.dim; j++) {
            if (this.maze[i][j].explored && this.updateValue(i, j)) changed = true;
        }
    }
    return changed;
};

Maze.prototype.calculateValueFunction = function () {
    while (this.updateValues());
};

Maze.prototype.resetValues = function () {
    for (var i = 0; i < this.dim; i++) {
        for (var j = 0; j < this.dim; j++) {
            var cell = this.maze[i][j];
            cell.value = 0;
            cell.moveNorth.q = cell.utility;
            cell.moveEast.q = cell.utility;
            cell.moveSouth.q = cell.utility;
            cell.moveWest.q = cell.utility;
        }
    }
};

Maze.prototype.resetExplored = function () {
    for (var i = 0; i < this.dim; i++) {
        for (var j = 0; j < this.dim; j++) {
            this.maze[i][j].explored = false;
        }
    }
};


Maze.prototype.generateMaze = function (x, y) {
    this.maze[x][y].visited = true;

    var found = false;
    if (x === this.dim - 1 && y === this.dim - 1) found = true;

    var temp = [0, 1, 2, 3];
    var order = [];
    for (var i = 0; i < 4; i++) {
        order.push(temp.splice(randomInt(temp.length), 1)[0]);
    }

    for (var i = 0; i < 4; i++) {
        if (order[i] === 0) {
            // north
            if (y !== 0 && !this.maze[x][y - 1].visited) {
                this.maze[x][y].north = this.maze[x][y - 1];
                this.maze[x][y - 1].south = this.maze[x][y];
                if (this.generateMaze(x, y - 1)) found = true;
            }
        } else if (order[i] === 1) {
            // east
            if (x !== this.dim - 1 && !this.maze[x + 1][y].visited) {
                this.maze[x][y].east = this.maze[x + 1][y];
                this.maze[x+1][y].west = this.maze[x][y];
                if(this.generateMaze(x + 1, y)) found = true;
            }
        } else if (order[i] === 2) {
            // south
            if (y !== this.dim - 1 && !this.maze[x][y + 1].visited) {
                this.maze[x][y].south = this.maze[x][y + 1];
                this.maze[x][y+1].north = this.maze[x][y];
                if(this.generateMaze(x, y + 1)) found = true;
            }
        } else if (order[i] === 3) {
            // west
            if (x !== 0 && !this.maze[x - 1][y].visited) {
                this.maze[x][y].west = this.maze[x - 1][y];
                this.maze[x - 1][y].east = this.maze[x][y];
                if(this.generateMaze(x - 1, y)) found = true;
            }
        }
    }
    if (found) this.maze[x][y].solution = true;
    return found;
}

Maze.prototype.update = function(){
};

Maze.prototype.draw = function (ctx) {
    var length = 800 / this.dim;
    var width = length / 20;

    var showSolution = document.getElementById("show_solution").checked;
    //var showValues = document.getElementById("show_value").checked;
    var showRewards = document.getElementById("show_reward").checked;
    var showQ = document.getElementById("q").checked;
    var fog = document.getElementById("fog").checked;

    if (this.icy) {
        ctx.fillStyle = "lightblue";
        ctx.fillRect(0, 0, 800, 800);
    }
 
    for (var i = 0; i < this.dim; i++) {
        for (var j = 0; j < this.dim; j++) {
            ctx.strokeStyle = "gray";
            ctx.strokeRect(i * length, j * length, length, length);
        }
    }

    for (var i = 0; i < this.dim; i++) {
        for (var j = 0; j < this.dim; j++) {
            if (this.maze[i][j].utility === this.reward) {
                ctx.drawImage(ASSET_MANAGER.getAsset("Pot_Gold.png"), i * length + 0.25*length, j * length + 0.25*length, 0.5*length, 0.5*length);
            }
            if (this.maze[i][j].pit) {
                ctx.drawImage(ASSET_MANAGER.getAsset("pit.png"), i * length, j * length, length, length);
            }
            ctx.fillStyle = "red";
            if (!this.maze[i][j].north) ctx.fillRect(i * length, j * length, length, width);
            if (!this.maze[i][j].south) ctx.fillRect(i * length, j * length + length - width, length, width);
            if (!this.maze[i][j].west) ctx.fillRect(i * length, j * length, width, length);
            if (!this.maze[i][j].east) ctx.fillRect(i * length + length - width, j * length, width, length);
            ctx.fillStyle = "green";
            if (this.maze[i][j].solution && showSolution) {
                if (this.maze[i][j].north && j > 0 && this.maze[i][j - 1].solution) { // north
                    ctx.fillRect(i * length + length / 2 - width / 2, j * length, width, length / 2 + width / 2);
                }
                if (this.maze[i][j].south && j < this.dim - 1 && this.maze[i][j + 1].solution) { // south
                    ctx.fillRect(i * length + length / 2 - width / 2, j * length + length / 2 - width / 2, width, length / 2 + width / 2);
                }
                ctx.fillRect(i * length + length / 2 - width / 2, j * length + length / 2 - width / 2, width, width);
                if (this.maze[i][j].west && i > 0 && this.maze[i - 1][j].solution) { // west
                    ctx.fillRect(i * length, j * length + length / 2 - width / 2, length / 2 + width / 2, width);
                }
                if (this.maze[i][j].east && i < this.dim - 1 && this.maze[i + 1][j].solution) { // east
                    ctx.fillRect(i * length + length / 2 - width / 2, j * length + length / 2 - width / 2, length / 2 + width / 2, width);
                }
                ctx.fillRect(i * length + length / 2 - width / 2, j * length + length / 2 - width / 2, width, width);
            }
        }
    }

    for (var i = 0; i < this.dim; i++) {
        for (var j = 0; j < this.dim; j++) {
            ctx.font = "12px Arial";
            if (showRewards) {
                if (this.maze[i][j].pit) ctx.fillStyle = "white"; else ctx.fillStyle = "black";
                ctx.fillText(this.maze[i][j].utility, i * length + width + 2, j * length + width + 12);
            }
            if (!showQ) {
                if (this.maze[i][j].pit) ctx.fillStyle = "yellow"; else ctx.fillStyle = "blue";
                ctx.fillText(Math.floor(this.maze[i][j].value * 100) / 100, i * length + width + 2, j * length + length - width - 12);
            }
            if (showQ && !this.maze[i][j].final) {
                if (this.maze[i][j].pit) ctx.fillStyle = "pink"; else ctx.fillStyle = "purple";
                ctx.fillText(Math.floor(this.maze[i][j].moveNorth.q * 10) / 10, i * length + length / 3 + 2, j * length + width + 12);
                if (this.maze[i][j].pit) ctx.fillStyle = "pink"; else ctx.fillStyle = "purple";
                ctx.fillText(Math.floor(this.maze[i][j].moveEast.q * 10) / 10, i * length + 3*length/4 - 12, j * length + length/3 + width + 12);
                if (this.maze[i][j].pit) ctx.fillStyle = "pink"; else ctx.fillStyle = "purple";
                ctx.fillText(Math.floor(this.maze[i][j].moveSouth.q * 10) / 10, i * length + length / 3 + 2, j * length + length - width);
                if (this.maze[i][j].pit) ctx.fillStyle = "pink"; else ctx.fillStyle = "purple";
                ctx.fillText(Math.floor(this.maze[i][j].moveWest.q * 10) / 10, i * length + width + 2, j * length + length / 3 + width + 12);
            }
            if (fog && !this.maze[i][j].explored) {
                ctx.save();
                ctx.globalAlpha = 0.75;
                ctx.fillStyle = "black";
                ctx.fillRect(i*length,j*length,length,length);
                ctx.restore();
            }
        }
    }
};

function newFourByThree(gameEngine) {
    var maze = new Maze(gameEngine, 0);
    gameEngine.entities = [];
    gameEngine.addEntity(maze);

    var allUpdate = document.getElementById("all_update");
    var valFunc = document.getElementById("value_function");
    var reset = document.getElementById("reset");

    allUpdate.onclick = function () {
        maze.updateValues();
    };

    valFunc.onclick = function () {
        maze.calculateValueFunction();
    };

    reset.onclick = function () {
        maze.resetValues();
    }

};

function newMaze(gameEngine) {
    var maze = new Maze(gameEngine, 1);
    gameEngine.entities = [];
    gameEngine.addEntity(maze);
    //newAgent(gameEngine);

    var allUpdate = document.getElementById("all_update");
    var valFunc = document.getElementById("value_function");
    var reset = document.getElementById("reset");

    allUpdate.onclick = function () {
        maze.updateValues();
    };

    valFunc.onclick = function () {
        maze.calculateValueFunction();
    };

    reset.onclick = function () {
        maze.resetValues();
    }

};

function newBridge(gameEngine) {
    var maze = new Maze(gameEngine, 2);
    gameEngine.entities = [];
    gameEngine.addEntity(maze);
    //newAgent(gameEngine);

    var allUpdate = document.getElementById("all_update");
    var valFunc = document.getElementById("value_function");
    var reset = document.getElementById("reset");

    allUpdate.onclick = function () {
        maze.updateValues();
    };

    valFunc.onclick = function () {
        maze.calculateValueFunction();
    };

    reset.onclick = function () {
        maze.resetValues();
    }

};

function newAgent(gameEngine) {
    var agent = new Agent(gameEngine, gameEngine.entities[0]);
    gameEngine.entities[0].resetValues();
    gameEngine.entities[0].resetExplored();
    if (gameEngine.entities[1]) gameEngine.entities[1].removeFromWorld = true;
    gameEngine.addEntity(agent);
};


var ASSET_MANAGER = new AssetManager();

ASSET_MANAGER.queueDownload("robo1.png");
ASSET_MANAGER.queueDownload("pit.png");
ASSET_MANAGER.queueDownload("Pot_Gold.png");

ASSET_MANAGER.downloadAll(function () {
    var canvas = document.getElementById('gameWorld');
    var ctx = canvas.getContext('2d');

    var gameEngine = new GameEngine();
    gameEngine.init(ctx);
    gameEngine.start();
    newFourByThree(gameEngine);

    var new4 = document.getElementById("new_43");
    var newB = document.getElementById("new_bridge");
    var newM = document.getElementById("new_maze");
    var newA = document.getElementById("new_agent");
    var del = document.getElementById("delete");

    new4.onclick = function () {
        newFourByThree(gameEngine);
    };

    newB.onclick = function () {
        newBridge(gameEngine);
    };

    newM.onclick = function () {
        newMaze(gameEngine);
    };

    newA.onclick = function () {
        newAgent(gameEngine);
    };

    del.onclick = function () {
        gameEngine.entities[0].resetValues();
        gameEngine.entities[0].resetExplored();
        if (gameEngine.entities[1]) gameEngine.entities[1].removeFromWorld = true;
    }
});
